package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RadioGroup;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private WordAdapter wordAdapter;
    private ArrayList<String> wordList;
    private ProgressBar progressBar;

    private RadioGroup radioGroup;
    private String currentUrl;

    private static final String SELECTED_RADIO_BUTTON_KEY = "selected_radio_button";
    private static final String CURRENT_URL_KEY = "current_url";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        progressBar = findViewById(R.id.progressBar);
        radioGroup = findViewById(R.id.radioGroup);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        wordList = new ArrayList<>();
        wordAdapter = new WordAdapter(this, wordList);
        recyclerView.setAdapter(wordAdapter);

        // Initialize SharedPreferences
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        int selectedRadioButtonId = sharedPreferences.getInt(SELECTED_RADIO_BUTTON_KEY, R.id.radioEnglish);
        radioGroup.check(selectedRadioButtonId);

        currentUrl = sharedPreferences.getString(CURRENT_URL_KEY, "https://thelightsurprise.com/english.json");

        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putInt(SELECTED_RADIO_BUTTON_KEY, checkedId);

            if (checkedId == R.id.radioEnglish) {
                currentUrl = "https://thelightsurprise.com/english.json";
                wordList.clear();
            } else if (checkedId == R.id.radioBangla) {
                currentUrl = "https://thelightsurprise.com/bangla.json";
                wordList.clear();
            }

            editor.putString(CURRENT_URL_KEY, currentUrl);
            editor.apply();

            fetchWords();
        });

        fetchWords();
    }

    private void fetchWords() {
        progressBar.setVisibility(View.VISIBLE);

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, currentUrl, null,
                response -> {
                    try {
                        JSONArray jsonArray = response.getJSONArray("wordList");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            String word = jsonArray.getString(i);
                            wordList.add(word);
                        }
                        wordAdapter.notifyDataSetChanged();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    progressBar.setVisibility(View.GONE);
                },
                error -> {
                    progressBar.setVisibility(View.GONE);
                });

        requestQueue.add(jsonObjectRequest);
    }
}
